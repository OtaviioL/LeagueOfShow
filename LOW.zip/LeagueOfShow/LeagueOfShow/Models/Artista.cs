﻿using System.ComponentModel.DataAnnotations.Schema;

namespace LeagueOfShow.Models
{
    public class Artista
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Nacionalidade { get; set; }

        public int BandaId { get; set; }
        [ForeignKey("BandaId")]

        public Banda banda { get; set; }

   

    }
}
