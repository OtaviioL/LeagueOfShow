﻿namespace LeagueOfShow.Models
{
    public class Banda
    {
        public int Id { get; set; }
        public string Nome { get; set; }

        
    }
}
