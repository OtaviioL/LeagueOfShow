﻿namespace LeagueOfShow.Models
{
    public class artbandsModel : Artista
    {

        

        public List<Banda> ListaBanda { get; set; }
    }
}
