﻿
namespace LeagueOfShow.Models
{
    public class Show
    {
        public int Id { get; set; }
        public string Nome { get; set; }
      
    }
}
