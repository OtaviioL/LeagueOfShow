﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LeagueOfShow.Migrations
{
    /// <inheritdoc />
    public partial class relacao2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "BandaId",
                table: "Artistas",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Artistas_BandaId",
                table: "Artistas",
                column: "BandaId");

            migrationBuilder.AddForeignKey(
                name: "FK_Artistas_Banda_BandaId",
                table: "Artistas",
                column: "BandaId",
                principalTable: "Banda",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Artistas_Banda_BandaId",
                table: "Artistas");

            migrationBuilder.DropIndex(
                name: "IX_Artistas_BandaId",
                table: "Artistas");

            migrationBuilder.DropColumn(
                name: "BandaId",
                table: "Artistas");
        }
    }
}
