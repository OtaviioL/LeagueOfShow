﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LeagueOfShow.Migrations
{
    /// <inheritdoc />
    public partial class m7 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ArtistaId",
                table: "Banda",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Banda_ArtistaId",
                table: "Banda",
                column: "ArtistaId");

            migrationBuilder.AddForeignKey(
                name: "FK_Banda_Artistas_ArtistaId",
                table: "Banda",
                column: "ArtistaId",
                principalTable: "Artistas",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Banda_Artistas_ArtistaId",
                table: "Banda");

            migrationBuilder.DropIndex(
                name: "IX_Banda_ArtistaId",
                table: "Banda");

            migrationBuilder.DropColumn(
                name: "ArtistaId",
                table: "Banda");
        }
    }
}
