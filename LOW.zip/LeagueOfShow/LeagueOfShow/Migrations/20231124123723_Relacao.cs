﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LeagueOfShow.Migrations
{
    /// <inheritdoc />
    public partial class Relacao : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Banda_Artistas_artistaId",
                table: "Banda");

            migrationBuilder.DropIndex(
                name: "IX_Banda_artistaId",
                table: "Banda");

            migrationBuilder.DropColumn(
                name: "artistaId",
                table: "Banda");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "artistaId",
                table: "Banda",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Banda_artistaId",
                table: "Banda",
                column: "artistaId");

            migrationBuilder.AddForeignKey(
                name: "FK_Banda_Artistas_artistaId",
                table: "Banda",
                column: "artistaId",
                principalTable: "Artistas",
                principalColumn: "Id");
        }
    }
}
